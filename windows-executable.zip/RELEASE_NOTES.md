# Release Notes
## Version: main
## Build Date: 08/15/2025 00:18:00
## Platform: Windows
## Usage: my-app.exe <nodeId>
